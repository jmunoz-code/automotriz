# serializers.py
from rest_framework import serializers
from presupuesto.models import Presupuesto

from .models import PagoCuotas
from clientes.models import Clientes

class PagoCuotasSerializer(serializers.ModelSerializer):
    fono = serializers.SerializerMethodField()
    nombres = serializers.SerializerMethodField()
    apellidos = serializers.SerializerMethodField()

    interes_mensual = serializers.SerializerMethodField()
    monto_a_financiar = serializers.SerializerMethodField()
    abono_total = serializers.IntegerField(read_only=True)
    numero_cuotas = serializers.SerializerMethodField()
    precio_venta = serializers.SerializerMethodField()
    valor_pie = serializers.SerializerMethodField()
    interes_mensual = serializers.SerializerMethodField()
    fecha_creacion = serializers.SerializerMethodField()
        


    class Meta:
        model = PagoCuotas
        fields = '__all__'

    def get_fono(self, obj):
        try:
            cliente = Clientes.objects.get(rut=obj.rut_cliente)
            return cliente.fono
        except Clientes.DoesNotExist:
            return None
        
    def get_nombres(self, obj):
        try:
            cliente = Clientes.objects.get(rut=obj.rut_cliente)
            return cliente.nombres
        except Clientes.DoesNotExist:
            return None
        
    def get_apellidos(self, obj):
        try:
            cliente = Clientes.objects.get(rut=obj.rut_cliente)
            return  cliente.apellidos
        except Clientes.DoesNotExist:
            return None
   

    

    def get_monto_a_financiar(self, obj):
        presupuesto = Presupuesto.objects.filter(
            rut_cliente=obj.rut_cliente,
            patente_vehiculo=obj.patente
        ).first()
        if presupuesto:
            return presupuesto.monto_a_financiar
        return None
    
    def get_numero_cuotas(self, obj):
        presupuesto = Presupuesto.objects.filter(
            rut_cliente=obj.rut_cliente,
            patente_vehiculo=obj.patente
        ).first()
        if presupuesto:
            return presupuesto.numero_cuotas
        return None
    
    def get_precio_venta(self, obj):
        presupuesto = Presupuesto.objects.filter(
            rut_cliente=obj.rut_cliente,
            patente_vehiculo=obj.patente
        ).first()
        if presupuesto:
            return presupuesto.precio_venta
        return None
    
    def get_valor_pie(self, obj):
        presupuesto = Presupuesto.objects.filter(
            rut_cliente=obj.rut_cliente,
            patente_vehiculo=obj.patente
        ).first()
        if presupuesto:
            return presupuesto.valor_pie
        return None
    
    def get_interes_mensual(self, obj):
        presupuesto = Presupuesto.objects.filter(
            rut_cliente=obj.rut_cliente,
            patente_vehiculo=obj.patente
        ).first()
        if presupuesto:
            return presupuesto.interes_mensual
        return None
    
    def get_fecha_creacion(self, obj):
        presupuesto = Presupuesto.objects.filter(
            rut_cliente=obj.rut_cliente,
            patente_vehiculo=obj.patente
        ).first()
        if presupuesto:
            return presupuesto.fecha_creacion
        return None