# views.py
from django.db.models import Sum, OuterRef, Subquery, DecimalField, F, Q # ⬅️ Importar Q
from django.db.models.functions import Coalesce
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.db import transaction
from django.utils import timezone
from datetime import date, timedelta
from dateutil.relativedelta import relativedelta
from decimal import Decimal, ROUND_HALF_UP 

# Importa tus serializadores y modelos
from detallePagoCuotas.serializers import DetallePagoCuotasSerializer
from pagoCuotas.serializers import PagoCuotasSerializer
from .models import PagoCuotas as Cuota
from detallePagoCuotas.models import DetallePagoCuotas
from clientes.models import Clientes # ⬅️ Asegúrate de tener este import
from presupuesto.models import Presupuesto # Asumiendo que Presupuesto es necesario


class PagoCuotasAPIView(APIView):

    def post(self, request, format=None):
        
        # 1. LECTURA CRÍTICA: Leer del cuerpo de la solicitud (JSON del POST)
        params = request.data # <--- ¡CAMBIO CLAVE! Esto soluciona los errores 400 y 405 anteriores.

        try:
            # 2. Extracción y Conversión de Parámetros (Usamos str() para que Decimal lea correctamente)
            rut_cliente = params['rut_cliente']
            patente = params['patente']
            cantidad_cuotas = int(params['numero_cuota'])
            
            # Convertir todos los valores monetarios/porcentuales a Decimal para cálculos precisos
            monto_cuota_fija = Decimal(str(params['monto_cuota'])).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
            monto_prestamo = Decimal(str(params['monto_prestamo'])).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
            interes_mensual = Decimal(str(params['interes_mensual']))

            fecha_vencimiento_inicial = date.fromisoformat(params['fecha_vencimiento'])
            
            # Tasa de interés mensual (Ej: 1.5% -> 0.015)
            interes_mensual_tasa = (interes_mensual / 100).quantize(Decimal('0.000001'), rounding=ROUND_HALF_UP)

            saldo_pendiente = monto_prestamo 
            generated_cuotas = [] # Lista para recolectar cuotas para la respuesta

            # 3. Lógica de Generación de Cuotas (Tabla de Amortización)
            with transaction.atomic():
                
                # PREVENCIÓN: Eliminar cuotas anteriores para este contrato
                Cuota.objects.filter(rut_cliente=rut_cliente, patente=patente).delete()

                for i in range(cantidad_cuotas):
                    
                    # 3.1 Fecha
                    fecha_cuota = (fecha_vencimiento_inicial + relativedelta(months=i))
                    
                    # 3.2 CÁLCULO DE INTERÉS (siempre redondeado a 2 decimales)
                    interes_esta_cuota = (saldo_pendiente * interes_mensual_tasa).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
                    
                    # 3.3 ABONO A CAPITAL (cuota fija - interés, redondeado a 2 decimales)
                    capital_amortizado_esta_cuota = (monto_cuota_fija - interes_esta_cuota).quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)
                    
                    # 3.4 Actualización del saldo pendiente (temporal)
                    saldo_pendiente -= capital_amortizado_esta_cuota
                    
                    # 3.5 AJUSTE DE LA ÚLTIMA CUOTA (CRÍTICO para cuadrar el préstamo a cero)
                    if i == cantidad_cuotas - 1:
                        # Si es la última cuota, el capital debe cubrir el saldo restante
                        # (Generalmente corrige errores de redondeo de 1 o 2 centavos)
                        capital_amortizado_esta_cuota += saldo_pendiente.quantize(Decimal('0.01')) 
                        saldo_pendiente = Decimal('0.00') # Forzamos el saldo a cero
                    
                    # 3.6 Creación de la instancia del modelo (Grabar en BDD)
                    Cuota.objects.create(
                        rut_cliente=rut_cliente,
                        patente=patente,
                        numero_cuota=i + 1,
                        fecha_vencimiento=fecha_cuota,
                        monto_cuota=monto_cuota_fija,
                        abono_capital=capital_amortizado_esta_cuota,
                        monto_prestamo=monto_prestamo,
                        interes_mensual=interes_mensual,
                        # fecha_pago y observacion se establecen por defecto a NULL
                    )
                
            # 4. Respuesta (Volvemos a buscar las cuotas para serializar la respuesta completa)
            generated_cuotas = Cuota.objects.filter(rut_cliente=rut_cliente, patente=patente).order_by('numero_cuota')
            response_serializer = PagoCuotasSerializer(generated_cuotas, many=True)
            return Response({'message': f'Cuotas generadas exitosamente ({cantidad_cuotas}) y guardadas en la base de datos.', 'data': response_serializer.data}, status=status.HTTP_201_CREATED)

        # 5. Manejo de Errores (Asegurar que siempre se devuelve un JSON válido)
        except KeyError as ke:
            # Faltan parámetros
            required_fields = ['rut_cliente', 'patente', 'numero_cuota', 'monto_cuota', 'monto_prestamo', 'interes_mensual', 'fecha_vencimiento']
            return Response({
                "error": f"Faltan datos en la solicitud: {str(ke)}.",
                "detalle": f"Asegúrese de enviar todos los campos requeridos en el JSON: {', '.join(required_fields)}."
            }, status=status.HTTP_400_BAD_REQUEST)
        
        except (ValueError, TypeError) as ve:
            # Error de conversión (Ej: texto en lugar de número, o fecha mal formada)
            return Response({
                "error": "Error de formato de datos.", 
                "detalle": f"Asegúrese de que los campos numéricos y de fecha (YYYY-MM-DD) estén correctos. Detalle: {str(ve)}"
            }, status=status.HTTP_400_BAD_REQUEST)
        
        except Exception as e:
            # Error interno del servidor (se imprimirá en la consola de Django)
            return Response({"error": f"Error interno del servidor al procesar la solicitud: {str(e)}"}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
  

    def get(self, request, format=None):
        """ Maneja la consulta y filtrado de cuotas con cálculo de abonos. """
        print("DEBUG: Entrando en PagoCuotasAPIView.get")

        rut_cliente = request.query_params.get('rut_cliente', None)
        patente = request.query_params.get('patente', None)
        nombres_filtro = request.query_params.get('nombres', None) # Término de búsqueda de nombres

        print(f"DEBUG: Parámetros de consulta para GET - rut_cliente: {rut_cliente}, patente: {patente}, nombres: {nombres_filtro}")

        # Subconsulta para calcular la suma de abonos (total_abonos_sum) para cada Cuota
        subquery_abonos = DetallePagoCuotas.objects.filter(
            rut=OuterRef('rut_cliente'),
            patente=OuterRef('patente'),
            numero_cuota=OuterRef('numero_cuota')
        ).values('rut', 'patente', 'numero_cuota').annotate(
            total_abonos_sum=Coalesce(Sum('monto_cuota'), 0, output_field=DecimalField())
        ).values('total_abonos_sum')[:1]

        # Anotar el total de abonos a cada objeto Cuota
        cuotas = Cuota.objects.annotate(
            abono_total=Subquery(subquery_abonos)
        ).all() 
        # ----------------------------------------------------------------------
# LÓGICA DE FILTRADO POR RUT Y PATENTE
# ----------------------------------------------------------------------
        if rut_cliente:
            cuotas = cuotas.filter(rut_cliente=rut_cliente)
        print(f"DEBUG: Filtrando por rut_cliente={rut_cliente}. Total: {cuotas.count()}")

        if patente:
            cuotas = cuotas.filter(patente=patente)
        print(f"DEBUG: Filtrando por patente={patente}. Total: {cuotas.count()}")

# ----------------------------------------------------------------------
# LÓGICA DE FILTRADO POR NOMBRES/APELLIDOS
# ----------------------------------------------------------------------
        if nombres_filtro:
            ruts_coincidentes = Clientes.objects.filter(
        Q(nombres__icontains=nombres_filtro) | 
        Q(apellidos__icontains=nombres_filtro)
        ).values_list('rut', flat=True)
   


        # Ordenar el resultado
        cuotas = cuotas.order_by('rut_cliente', 'patente', 'numero_cuota' )

        if not rut_cliente and not patente and not nombres_filtro:
            print(f"DEBUG: No se proporcionaron filtros. Obteniendo todas las cuotas y ordenándolas. Total: {cuotas.count()}")

        serializer = PagoCuotasSerializer(cuotas, many=True)
        
        return Response({'message': 'Cuotas obtenidas exitosamente', 'data': serializer.data}, status=status.HTTP_200_OK)


    def patch(self, request, pk, format=None):
        """ Actualiza parcialmente una cuota específica por ID. """
        print(f"DEBUG: Entrando en PagoCuotasAPIView.patch para PK: {pk}")

        try:
            cuota = Cuota.objects.get(pk=pk)
        except Cuota.DoesNotExist:
            print(f"ERROR: Cuota no encontrada con PK: {pk}")
            return Response({"message": "Cuota no encontrada."}, status=status.HTTP_404_NOT_FOUND)

        # Usar partial=True permite actualizar solo los campos proporcionados
        serializer = PagoCuotasSerializer(cuota, data=request.data, partial=True)

        if serializer.is_valid():
            serializer.save()
            print(f"DEBUG: Cuota con PK {pk} actualizada exitosamente.")
            return Response({'message': 'Cuota actualizada exitosamente', 'data': serializer.data}, status=status.HTTP_200_OK)
        else:
            print(f"ERROR: Error de validación en PATCH: {serializer.errors}")
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


# -----------------------------------------------------

class TodosRegistrosPorRutPatenteAPIView(APIView):
    """
    Recupera todos los registros de DetallePagoCuotas para un rut_cliente y patente específicos.
    """
    def get(self, request, format=None):
        print("DEBUG: Entrando en TodosRegistrosPorRutPatenteAPIView.get")

        rut_cliente = request.query_params.get('rut_cliente', None)
        patente = request.query_params.get('patente', None)

        print(f"DEBUG: Parámetros de consulta para GET - rut_cliente: {rut_cliente}, patente: {patente}")

        if not rut_cliente or not patente:
            print("ERROR: RUT de cliente y Patente son requeridos para obtener todos los registros.")
            return Response(
                {"message": "RUT de cliente y Patente son requeridos para obtener todos los registros de cuotas."},
                status=status.HTTP_400_BAD_REQUEST
            )

        registros = DetallePagoCuotas.objects.filter(
            rut_cliente=rut_cliente,
            patente=patente
        ).order_by('numero_cuota')

        print(f"DEBUG: Registros obtenidos para RUT '{rut_cliente}' y Patente '{patente}'. Total: {registros.count()}")

        serializer = DetallePagoCuotasSerializer(registros, many=True)
        print("DEBUG: Registros serializados para la respuesta GET.")
        return Response({'message': 'Registros obtenidos exitosamente', 'data': serializer.data}, status=status.HTTP_200_OK)


# -----------------------------------------------------

class EliminarCuotasPorRutPatenteAPIView(APIView):
    """
    Gestiona la eliminación masiva de cuotas por rut_cliente y patente.
    """
    def delete(self, request, *args, **kwargs):
        print("DEBUG: Entrando en EliminarCuotasPorRutPatenteAPIView.delete")

        rut_cliente = request.data.get('rut_cliente')
        patente = request.data.get('patente')

        print(f"DEBUG: Solicitud de eliminación para RUT: {rut_cliente}, Patente: {patente}")

        if not rut_cliente or not patente:
            print("ERROR: RUT de cliente o patente no proporcionados para la eliminación.")
            return Response(
                {"message": "RUT de cliente y patente son requeridos para la eliminación."},
                status=status.HTTP_400_BAD_REQUEST
            )

        try:
            cuotas_eliminadas, _ = Cuota.objects.filter(rut_cliente=rut_cliente, patente=patente).delete()

            if cuotas_eliminadas > 0:
                print(f"DEBUG: {cuotas_eliminadas} cuota(s) eliminada(s) exitosamente para RUT: {rut_cliente}, Patente: {patente}")
                return Response(
                    {"message": f"{cuotas_eliminadas} cuota(s) eliminada(s) exitosamente."},
                    status=status.HTTP_200_OK
                )
            else:
                print(f"DEBUG: No se encontraron cuotas para eliminar con el RUT: {rut_cliente} y Patente: {patente}.")
                return Response(
                    {"message": "No se encontraron cuotas para los criterios especificados."},
                    status=status.HTTP_404_NOT_FOUND
                )
        except Exception as e:
            print(f"ERROR: Excepción inesperada en EliminarCuotasPorRutPatenteAPIView: {str(e)}")
            return Response(
                {"message": f"Error interno del servidor: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )
        
# -----------------------------------------------------

class CuotasImpagasAPIView(APIView):
    """
    Recupera cuotas con monto_cuota > abono_capital, opcionalmente filtradas por rango de fecha de vencimiento.
    Calcula los días de atraso.
    """
    def get(self, request, format=None):
        print("DEBUG: Entrando en CuotasImpagasAPIView.get")
        try:
            # Obtener los parámetros de fecha del request
            fecha_inicio_str = request.query_params.get('fecha_inicio')
            fecha_fin_str = request.query_params.get('fecha_fin')
            
            # Convertir las strings a objetos date, si existen
            fecha_inicio = date.fromisoformat(fecha_inicio_str) if fecha_inicio_str else None
            fecha_fin = date.fromisoformat(fecha_fin_str) if fecha_fin_str else None

            # 1. Filtrar las cuotas que están impagas (monto_cuota > abono_capital)
            cuotas_impagas = Cuota.objects.filter(monto_cuota__gt=F('abono_capital'))
            
            # 2. Aplicar filtro por rango de fechas de vencimiento si se proporcionaron
            if fecha_inicio:
                cuotas_impagas = cuotas_impagas.filter(fecha_vencimiento__gte=fecha_inicio)
            if fecha_fin:
                cuotas_impagas = cuotas_impagas.filter(fecha_vencimiento__lte=fecha_fin)
            
            # 3. Ordenar por fecha de vencimiento ascendente (más antiguas primero)
            cuotas_impagas = cuotas_impagas.order_by('fecha_vencimiento')

            # 4. Calcular los días de atraso para cada cuota y agregarlo a los datos
            hoy = timezone.localdate()
            data = []
            for cuota in cuotas_impagas:
                serializer = PagoCuotasSerializer(cuota)
                cuota_data = serializer.data
                
                # Calcular días de atraso solo si la cuota está vencida (fecha_vencimiento < hoy)
                if cuota.fecha_vencimiento and cuota.fecha_vencimiento < hoy:
                    dias_atraso = (hoy - cuota.fecha_vencimiento).days
                    cuota_data['dias_atraso'] = dias_atraso
                else:
                    cuota_data['dias_atraso'] = 0
                
                data.append(cuota_data)

            return Response(data, status=status.HTTP_200_OK)

        except Exception as e:
            print(f"ERROR: Excepción en CuotasImpagasAPIView: {str(e)}")
            return Response(
                {"message": f"Error interno del servidor: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )

# -----------------------------------------------------

class EliminarCuotasPoridAPIView(APIView):
    """
    Elimina una cuota específica por su ID (PK).
    """
    def delete(self, request, id):
        print(f"DEBUG: Entrando en EliminarCuotasPoridAPIView.delete para ID: {id}")
        try:
            num_eliminados, _ = Cuota.objects.filter(id=id).delete()

            if num_eliminados > 0:
                print(f"DEBUG: {num_eliminados} cuota(s) eliminada(s) exitosamente para ID: {id}")
                return Response(
                    {"message": f"{num_eliminados} cuota(s) eliminada(s) exitosamente."},
                    status=status.HTTP_200_OK
                )
            else:
                print(f"DEBUG: No se encontró cuota para eliminar con el ID: {id}.")
                return Response(
                    {"message": "No se encontró la cuota para el ID especificado."},
                    status=status.HTTP_404_NOT_FOUND
                )
        except Exception as e:
            print(f"ERROR: Excepción inesperada en EliminarCuotasPoridAPIView: {str(e)}")
            return Response(
                {"message": f"Error interno del servidor: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )