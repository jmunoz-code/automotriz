from django.urls import path
from .views import *

urlpatterns = [
    path('vehiculos/',Clase1.as_view()),
    path('vehiculos/<str:patente>/',Clase2.as_view())
]


