from urllib import request # This import seems unused. You can likely remove it.
from django.shortcuts import render # This import seems unused. You can likely remove it.
from http import HTTPStatus
from rest_framework.views import APIView
from rest_framework.response import Response
from django.http.response import JsonResponse
from django.http import Http404
from rest_framework.exceptions import ValidationError, NotFound
import json # Import json for better debugging print if needed

from .models import Vehiculos
from .serializers import VehiculosSerializer # Assuming your serializer is in the same app or path


class Clase1(APIView):
  
    def get(self, request):
      
        data = Vehiculos.objects.order_by('-id').all()
        serializer = VehiculosSerializer(data, many=True)
        return JsonResponse({"data": serializer.data}, status=HTTPStatus.OK)

    def post(self, request):
  
        # Create a mutable copy of request.data to modify
        modified_data = request.data.copy()

        # Apply uppercasing to specific string fields if they exist
        if 'modelo' in modified_data and modified_data['modelo']:
            modified_data['modelo'] = modified_data['modelo'].upper()
        if 'numero_motor' in modified_data and modified_data['numero_motor']:
            modified_data['numero_motor'] = modified_data['numero_motor'].upper()
        if 'numero_chasis' in modified_data and modified_data['numero_chasis']:
            modified_data['numero_chasis'] = modified_data['numero_chasis'].upper()
        if 'color' in modified_data and modified_data['color']:
            modified_data['color'] = modified_data['color'].upper()
        if 'patente' in modified_data and modified_data['patente']:
            modified_data['patente'] = modified_data['patente'].upper()

     

        # Initialize the serializer with the modified data
        serializer = VehiculosSerializer(data=modified_data)

        if serializer.is_valid():
            serializer.save() # Saves the validated data to the database
            return Response(
                {"estado": "ok", "message": "Se crea el registro exitosamente", "data": serializer.data},
                status=HTTPStatus.CREATED,
            )
        else:
            # Return serializer errors if validation fails
            return Response(serializer.errors, status=HTTPStatus.BAD_REQUEST)


class Clase2(APIView):
    """
    API View for handling operations on a single Vehiculo instance (GET, PUT, DELETE).
    """
    def get(self, request, patente):
        """
        Retrieves a single vehicle by its patent.
        """
        try:
            # Ensure the patent from the URL is uppercased for consistent lookup
            data = Vehiculos.objects.filter(patente=patente.upper()).get()
            
            # Manually construct the response data dictionary
            # Consider using a serializer for GET to handle field selection and relationships more cleanly
            response_data = {
                "modelo": data.modelo,
                "agno": data.agno,
                "numero_motor": data.numero_motor,
                "numero_chasis": data.numero_chasis,
                "color": data.color,
                "patente": data.patente,
                "kilometraje": data.kilometraje,
                "precio_compra": data.precio_compra,
                "precio_venta": data.precio_venta,
                "tipo_combustible": data.tipo_combustible,
                "tipo_vehiculo_id": data.tipo_vehiculo_id,
                "tipo_trasmision": data.tipo_trasmision,
                "tipo_marca_id": data.tipo_marca_id,
                "estado": data.estado,
                
            }
            # Add related descriptions if the relationships are defined and accessible
            if hasattr(data, 'tipo_marca') and data.tipo_marca:
                 response_data["marca_descripcion"] = data.tipo_marca.descripcion
            if hasattr(data, 'tipo_vehiculo') and data.tipo_vehiculo:
                response_data["vehiculo_descripcion"] = data.tipo_vehiculo.descripcion

            return JsonResponse({"data": response_data}, status=HTTPStatus.OK)
        except Vehiculos.DoesNotExist:
            raise Http404("Vehículo no encontrado.") # Raising Http404 makes DRF return a 404 response

    def put(self, request, patente):
        """
        Updates an existing vehicle record by its patent.
        Applies uppercasing to specific string fields and handles kilometraje conversion.
        Uses a serializer for validation and partial updates.
        """
        try:
            # Convert the patente from the URL to uppercase for the lookup
            patente_upper = patente.upper()
            vehiculos = Vehiculos.objects.filter(patente=patente_upper).get()

            # --- DEBUGGING (Use these for development, remove in production) ---
            print("\n--- DEBUG PUT Request ---")
            print("Patente a buscar (de URL, Uppercase):", patente_upper)
            print("request.data (raw como lo recibe DRF):", request.data)
            # print("request.data (JSON serializado):", json.dumps(request.data)) # Uncomment if needed
            # --- END DEBUGGING ---

            # Create a mutable copy of request.data to modify
            # request.data is often ImmutableDict, so we copy it to modify
            modified_data = request.data.copy()

            # Apply uppercasing to specific fields from the request body
            # Check if the field exists in the received data before trying to uppercase
            if 'patente' in modified_data and modified_data['patente']:
                modified_data['patente'] = modified_data['patente'].upper()
            
            if 'numero_motor' in modified_data and modified_data['numero_motor']:
                modified_data['numero_motor'] = modified_data['numero_motor'].upper()
                
            if 'numero_chasis' in modified_data and modified_data['numero_chasis']:
                modified_data['numero_chasis'] = modified_data['numero_chasis'].upper()

            if 'color' in modified_data and modified_data['color']:
                modified_data['color'] = modified_data['color'].upper() 

            # Handle kilometraje cleaning (from string with dots to integer)
            if 'kilometraje' in modified_data and modified_data['kilometraje']:
                try:
                    # Remove dots and convert to integer
                    cleaned_kilometraje = str(modified_data['kilometraje']).replace('.', '')
                    modified_data['kilometraje'] = int(cleaned_kilometraje)
                except ValueError:
                    # Return a specific error for invalid kilometraje
                    return Response(
                        {"kilometraje": ["El kilometraje debe ser un número válido."]},
                        status=HTTPStatus.BAD_REQUEST
                    )

            # Pass the modified data to the serializer
            # Use partial=True to allow incomplete updates (only update provided fields)
            serializer = VehiculosSerializer(vehiculos, data=modified_data, partial=True)

            print("serializer.initial_data (después de tus transformaciones):", serializer.initial_data)

            if serializer.is_valid():
                print("Serializer es VÁLIDO. Datos validados:", serializer.validated_data)
                serializer.save() # This saves the validated data to the database
                return Response(
                    {"data": serializer.data, "message": "Vehiculo modificado exitosamente"},
                    status=HTTPStatus.OK
                )
            else:
                print("Serializer es INVÁLIDO. Errores:", serializer.errors)
                return Response(serializer.errors, status=HTTPStatus.BAD_REQUEST)

        except Vehiculos.DoesNotExist:
            # Return 404 if the vehicle isn't found
            return Response({"error": "Vehículo no encontrado"}, status=HTTPStatus.NOT_FOUND)
        except Exception as e:
            # Catch any other unexpected errors
            print(f"Ocurrió un error inesperado en el PUT: {e}")
            return Response(
                {"error": f"Ocurrió un error inesperado al modificar: {e}"},
                status=HTTPStatus.INTERNAL_SERVER_ERROR
            )

    def delete(self, request, patente):
        """
        Deletes a vehicle record by its patent.
        """
        try:
            vehiculo = Vehiculos.objects.get(patente=patente.upper())
            vehiculo.delete()
            return Response(status=HTTPStatus.NO_CONTENT)  # Code 204 No Content
        except Vehiculos.DoesNotExist:
            raise NotFound(f"No se encontró ningún vehiculo con la patente: {patente.upper()}")
        except Exception as e:
            return Response({"error": f"Ocurrió un error inesperado al eliminar: {e}"}, status=HTTPStatus.INTERNAL_SERVER_ERROR)